import os

print("get UCLA data and prepare it into csv")


