# Data Preparation for Sentinel 2

print("Not ready yet..Prepare sentinel 2 into .csv")


