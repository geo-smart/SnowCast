# Find the best model
print("model comparison script")
print("hello world")
