
from base_hole import *

class KehanModel(BaseHole):
	
  def preprocessing():
    pass  
  
  def train():
    pass
  
  def test():
    pass
