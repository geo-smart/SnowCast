# GhostNet

print("Create GhostNet")


