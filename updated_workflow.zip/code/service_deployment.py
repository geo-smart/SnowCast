# Deploy model to service

print("deploy model to service")

